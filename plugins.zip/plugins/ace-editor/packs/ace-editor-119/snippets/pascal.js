ace.define("ace/snippets/pascal",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "pascal";

});
